#!/usr/bin/env python
#-*- coding: utf-8 -*-

import project2V2
from project2V2 import project2V2

def main():
    project2V2.user_program()

    
if __name__=='__main__':
    main()
